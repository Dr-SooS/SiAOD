﻿// LR1_4.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include "pch.h"
#include <cstdlib>
#include <iostream>
using namespace std;

template<class T>
struct snode {
	T      val;
	snode* next;
};

template<class T>
class slist {
	typedef snode<T> node;
private:
	node*  head;
	node*  tail;
	size_t cnt;
public:
	slist(void) :head(NULL), tail(NULL), cnt(0) {}
	slist(const slist&);
	~slist() {
		this->clear();
	}

	slist& operator = (const slist&);
public:
	bool add_front(const T& val) {
		node* p;
		try {
			p = new node();
		}
		catch (...) { return false; }

		p->val = val;
		p->next = NULL;
		if (head == NULL)
			head = tail = p;
		else {
			p->next = head;
			head = p;
		}
		++cnt;
		return true;
	}

	bool add_back(const T& val) {
		node* p;
		try {
			p = new node();
		}
		catch (...) { return false; }

		p->val = val;
		p->next = NULL;
		if (head == NULL)
			head = tail = p;
		else {
			tail->next = p;
			tail = p;
		}
		++cnt;
		return true;
	}

	void clear(void) {
		node* tmp;
		while (head != NULL) {
			tmp = head;
			head = head->next;
			delete tmp;
		}
		tail = NULL;
		cnt = 0;
	}

	size_t size(void) const { return cnt; }
	node*  begin(void) const { return head; }
	node*  begin(void) { return head; }
};


struct telnumb {
	char lname[32];
	int  group;
	telnumb(void) {}
	telnumb(const char* s, int g) {
		strcpy_s(lname, s);
		group = g;
	}
};

struct Node    
{
	int x;   
	Node *Next, *Prev;
};

class List   
{
	Node *Head, *Tail; 
public:
	List() :Head(NULL), Tail(NULL) {}; 
	~List(); 
	void ShowKon(); 
	void ShowNach();
	void Add(int x); 
};

List::~List()
{
	while (Head) 
	{
		Tail = Head->Next; 
		delete Head; 
		Head = Tail; 
	}
}

void List::Add(int x)
{
	Node *temp = new Node;
	temp->Next = NULL; 
	temp->x = x;

	if (Head != NULL)
	{
		temp->Prev = Tail; 
		Tail->Next = temp; 
		Tail = temp; 
	}
	else 
	{
		temp->Prev = NULL; 
		Head = Tail = temp; 
	}
}

void List::ShowKon()
{
	Node *temp = Tail;
	int mas[255];
	int k = 0;

	slist<telnumb> lst;

	while (temp != NULL) 
	{
		cout << temp->x << " ";
		if (temp->x > 999)
		{		
			mas[k] = temp->x;
			k++;
		}
		temp = temp->Prev;
	}
	int t;
	for (int i = 0; i < k - 1 ; i++) {
		for (int j = 0; j < k - i - 1; j++) {
			if (mas[j] > mas[j + 1]) {
				t = mas[j];
				mas[j] = mas[j + 1];
				mas[j + 1] = t;
			}
		}
	}

	cout << endl << "Otsortirovanniy odnonapravlenniy spisok bez specslujb:" << endl;

	for (int i = 0; i < k; i++)
	{
		lst.add_back(telnumb("aaa", mas[i]));
		cout << mas[i] << " ";
	}
	cout << "\n";
}

void List::ShowNach()
{
	Node *temp = Head;
	while (temp != NULL) 
	{
		cout << temp->x << " "; 
		temp = temp->Next; 
	}
	cout << "\n";
}

int main()
{
	system("CLS");
	List lst;
	lst.Add(101);
	lst.Add(102);
	lst.Add(103);
	lst.Add(104);
	lst.Add(2565456);
	lst.Add(1231231);
	lst.Add(8887776);
	lst.Add(5555555);

	cout << "Vse nomera: " << endl;
	lst.ShowNach(); 
	cout << "Sprava nalevo: " << endl;
	lst.ShowKon();
	system("PAUSE");
	return 0;
}