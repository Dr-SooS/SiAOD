﻿// LR1_3.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include "pch.h"
#include <iostream>
#include <string>

using namespace std;


template<class T>
struct snode {
	T      val;
	snode* next;
};

template<class T>
class slist {
	typedef snode<T> node;
private:
	node*  head;
	node*  tail;
	size_t cnt;
public:
	slist(void) :head(NULL), tail(NULL), cnt(0) {}
	slist(const slist&);
	~slist() {
		this->clear();
	}

	slist& operator = (const slist&);
public:
	bool add_front(const T& val) {
		node* p;
		try {
			p = new node();
		}
		catch (...) { return false; }

		p->val = val;
		p->next = NULL;
		if (head == NULL)
			head = tail = p;
		else {
			p->next = head;
			head = p;
		}
		++cnt;
		return true;
	}

	bool add_back(const T& val) {
		node* p;
		try {
			p = new node();
		}
		catch (...) { return false; }

		p->val = val;
		p->next = NULL;
		if (head == NULL)
			head = tail = p;
		else {
			tail->next = p;
			tail = p;
		}
		++cnt;
		return true;
	}

	void clear(void) {
		node* tmp;
		while (head != NULL) {
			tmp = head;
			head = head->next;
			delete tmp;
		}
		tail = NULL;
		cnt = 0;
	}

	size_t size(void) const { return cnt; }
	node*  begin(void) const { return head; }
	node*  begin(void) { return head; }
};


struct telnumb {
	char lname[32];
	int  group;
	telnumb(void) {}
	telnumb(const char* s, int g) {
		strcpy_s(lname, s);
		group = g;
	}
};


int main(void) {
	slist<telnumb> lst;
	lst.add_back(telnumb("Pavlov", 1234567));
	lst.add_back(telnumb("Petrov", 2345678));
	lst.add_front(telnumb("Lermontov", 3456789));
	lst.add_front(telnumb("Ivanov", 9876543));
	lst.add_front(telnumb("Andreev", 8765432));

	cout << "All numbers:" << endl;
	cout << "--------------------------------------" << endl;
	for (snode<telnumb>* i = lst.begin(); i != NULL; i = i->next) {
		cout << "FIO: " << i->val.lname << '\t'<< "Number: " << i->val.group << endl;
	}
	cout << "--------------------------------------" << endl;
	int keypressed = 0;
	do {
		cout << "Menu:" << endl;
		cout << "1. Poisk po nomeru" << endl;
		cout << "2. Poisk po familii" << endl;
		cout << "0. Exit" << endl;
		cin >> keypressed;
		switch (keypressed)
		{
		case 0:break;
		case 1: {
			int numbpoisk;
			bool poisk = false;
			cout << "Vvedite nomer dlya poiska" << endl;
			cin >> numbpoisk;
			if(numbpoisk<1111111 && numbpoisk>9999999)
			{
				cout << "Poisk ne del rezultatov" << endl;
			}
			cout << "--------------------------------------" << endl;
			for (snode<telnumb>* i = lst.begin(); i != NULL; i = i->next) {
				if (numbpoisk == i->val.group) {
					cout << "FIO: " << i->val.lname << endl;
					poisk = true;
				}
			}
			if (!poisk)
			{
				cout << "Poisk ne del rezultatov" << endl;
			}
			cout << "--------------------------------------" << endl;
			break;
		}
		case 2:
		{
			string fampoisk;
			bool poisk = false;
			cout << "Vvedite FIO dlya poiska" << endl;
			cin >> fampoisk;
			cout << "--------------------------------------" << endl;
			for (snode<telnumb>* i = lst.begin(); i != NULL; i = i->next) {
				if (fampoisk == i->val.lname) {
					cout << "Number: " << i->val.group << endl;
					poisk = true;
				}
			}
			if (!poisk)
			{
				cout << "Poisk ne del rezultatov" << endl;
			}
			cout << "--------------------------------------" << endl;
			break;
		}
		default:
		{

			break; 
		}
		}
	} while (keypressed != 0);
	lst.clear();
	system("pause");
	return 0;
}
