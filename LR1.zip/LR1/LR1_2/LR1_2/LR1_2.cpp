﻿// LR1_2.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include "pch.h"
#include <iostream>
#include <cstdlib>
#include <math.h>

using namespace std;

struct Node {
	int t;
	struct Node *next;
};

struct List {
	size_t size;
	Node *current;
};

struct List * init() {
	List *lst = (struct List*)malloc(sizeof(struct List));
	lst->size = 0;
	lst->current = nullptr;
	return lst;
}

void addElem(List *lst, int t) {
	Node *prev = nullptr;
	Node *tmp = (struct Node*)malloc(sizeof(struct Node));

	tmp->t = t;
	if (lst->current == nullptr) {
		lst->current = tmp;
		tmp->next = tmp;
	}
	else {
		tmp->next = lst->current->next;
		lst->current->next = tmp;
		lst->current = tmp;
	}
	lst->size++;
}

void deleteElem(List *lst) {
	Node *target = nullptr;
	Node *prev = lst->current->next;
	if (lst->current == nullptr)
		exit(1);
	if (lst->current->next == lst->current) {
		free(lst->current);
		lst->current = nullptr;
	}
	else {
		while (prev->next != lst->current) {
			prev = prev->next;
		}
		prev->next = lst->current->next;
		target = lst->current->next;
		free(lst->current);
		lst->current = prev;
	}
	lst->size--;
}

Node * next(List *lst) {
	Node *next = nullptr;
	if (lst->current) {
		lst->current = lst->current->next;
		next = lst->current;
	}
	return next;
}

void listPrint(List *lst) {
	Node *anchor = lst->current;
	if (anchor) {
		do {
			cout<<"Rebenok " <<anchor->t<<endl;
			anchor = anchor->next;
		} while (anchor != lst->current);
	}
}

void counter(List *lst, int k) {
	int new_k = k;
	while (lst->size >= 2) {
		for (int i = 0; i < new_k; ++i) {
			lst->current = next(lst);
		}
		deleteElem(lst);
		cout << "-----------" << endl;
		listPrint(lst);
	}
}

int main() {
	
	
	int n, k;
	cout << "Vvedite kolichestvo detey: "; cin >> n;
	cout << "Vvedite k: "; cin >> k;
	cout << "Vse deti:" << endl;
	struct List * circle;
	circle = init();

	for (int i = 1; i <= n; i++) {
			addElem(circle, i);
	}
	listPrint(circle);

	counter(circle, k);

	cout << "Pobeditel:" << endl;
	listPrint(circle);

	system("pause");
	return 0;
}