﻿#include "pch.h"
#include <iostream>
#include <cmath>

using namespace std;
bool equality(struct pxviraj p[], struct pxviraj q[], int lenp, int lenq);
void meaning(struct pxviraj p[], int x, int len);
void add(struct pxviraj p[], struct pxviraj q[], int lenp, int lenq);

struct pxviraj
{
	double n;
	int a;
};

int main()
{
	int stplen = 0, stqlen = 0;
	struct pxviraj p[255];
	struct pxviraj q[255];
	cout << "Vvedite 0 dlya 'a' dlya zaversheniya..." << endl;
	cout << "Vvodite P(x):" << endl;
	do
	{
		cout << "Vvedite n = ";
		cin >> p[stplen].n;
		cout << "Vvedite a = ";
		cin >> p[stplen].a;
		if (p[stplen].a == 0)
			break;
		stplen++;
	} while (true);
	cout << "Vvedite 0 dlya 'a' dlya zaversheniya..." << endl;
	cout << "Vvodite Q(x):" << endl;
	do
	{
		cout << "Vvedite n = ";
		cin >> q[stqlen].n;
		cout << "Vvedite a = ";
		cin >> q[stqlen].a;
		if (q[stqlen].a == 0)
			break;
		stqlen++;
	} while (true);

	int keypress = 0;
	do
	{
	cout << "Viberete funkciyu:" << endl;
	cout << "1. Equality" << endl;
	cout << "2. Meaning" << endl;
	cout << "3. Add" << endl;
	cout << "0. Exit" << endl;
	cin >> keypress;
	switch (keypress)
	{
	case 0: break;
	case 1: {
		if (equality(p,q,stplen,stqlen))
		{
			cout << "P(x) raven Q(x)" << endl;
		}
		else
		{
			cout << "P(x) ne raven Q(x)" << endl;
		}
		break;
	}
	case 2: {
		cout << "---------------------------" << endl;
		int x;
		cout << "Vvedite x = ";
		cin >> x;
		meaning(p,x,stplen);
		break; 
	}
	case 3: {
		add(p,q,stplen,stqlen);
		break; 
	}
	default:
	{
		cout << "Ne verno ukazana cifra" << endl;
		break;
	}
	}
	cout << "---------------------------" << endl;
	} while (keypress != 0);

	system("pause");
	return 0;
}

bool equality(struct pxviraj p[], struct pxviraj q[], int lenp, int lenq)
{
	cout << "---------------------------" << endl;
	double sumq = 0;
	double sump = 0;
	double max = 0;
	int x = 1;
	for (int i = 0; i < lenp; i++)
	{
		if (p[i].n > q[i].n && max < p[i].n)
			max = p[i].n;
		if (p[i].n < q[i].n && max < q[i].n)
			max = q[i].n;
	}
	
	for (int sv = max; sv >= 0; sv--)
	{
		int sravp = 0;
		int sravq = 0;
		for (int i = 0; i < lenp; i++)
		{
			if (p[i].n == sv)
				sravp = p[i].a;
		}
		for (int i = 0; i < lenq; i++)
		{
			if (q[i].n == sv)
				sravq = q[i].a;
		}
		if (sravq != sravp)
			return false;
	}
	return true;
}

void meaning(struct pxviraj p[],int x, int len)
{
	double sump = 0;
	for (int i = 0; i < len; i++)
	{
		sump = sump + p[i].a * pow(x, p[i].n);
	}
	cout << "P(" << x << ") = " << sump << endl;
}

void add(struct pxviraj p[], struct pxviraj q[], int lenp, int lenq)
{
	struct pxviraj tmp[255];
	struct pxviraj r[255];
	int k = 0;
	for (int i = 0; i < lenp; i++)
	{
		tmp[k].n = p[i].n;
		tmp[k].a = p[i].a;
		k++;
	}
	bool adding = true;
	for (int j = 0; j < lenq; j++)
	{
		for (int i = 0; i < k; i++)
		{	
			if (tmp[i].n == q[j].n)
			{
				tmp[i].a = tmp[i].a * q[j].a;
				adding = false;
			}
		}
		if (adding)
		{
			tmp[k].a = q[j].a;
			tmp[k].n = q[j].n;
			k++;
		}
		adding = true;
	}

	pxviraj temp;

	for (int i = k - 1; i >= 0; i--)
	{
		for (int j = 0; j < i; j++)
		{
			if (tmp[j].n > tmp[j+1].n)
			{
				temp = tmp[j];
				tmp[j] = tmp[j + 1];
				tmp[j + 1] = temp;
			}
		}
	}

	cout << "R(x)=";
	for (int i = k-1; i >= 0; i--)
	{
		if (tmp[i].n != 0) {
			if (tmp[i].n != 1 && tmp[i].a != 1)
				cout << abs(tmp[i].a) << "x^" << tmp[i].n;
			if (tmp[i].n != 1 && tmp[i].a == 1)
				cout << "x^" << tmp[i].n;
			if (tmp[i].n == 1 && tmp[i].a != 1)
				cout << abs(tmp[i].a) << "x";
			if (tmp[i].n == 1 && tmp[i].a == 1)
				cout << "x" << tmp[i].n;
		}
		else
		{
			cout << abs(tmp[i].a);
		}
		if (i != 0)
		{
			if (tmp[i - 1].a >= 0)
			{
				cout << " + ";
			}
			else
			{
				cout << " - ";
			}
		}
	}
	cout << endl;
}
